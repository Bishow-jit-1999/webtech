<?php

$token="";

session_start();
if(isset($_SESSION["uname"])){
  
    $token="signout.php";
    

}



?>

<!DOCTYPE html>
<html>
<head>
      <meta charset='utf-8'>
      <meta http-equiv='X-UA-Compatible' content='IE=edge'>
      <title>LUXURY CAR BD</title>
      <meta name='viewport' content='width=device-width, initial-scale=1'>
      <link rel='stylesheet' type='text/css' media='screen' href='STYLE.css'>
      <script src='main.js'></script>
      <script src="https://kit.fontawesome.com/c45e16e744.js" crossorigin="anonymous"></script>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,500;1,300&display=swap" rel="stylesheet">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script src="https://kit.fontawesome.com/c45e16e744.js" crossorigin="anonymous"></script>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   

<style>
.whole{
  text-align:center;
  margin:auto;
  margin-top:-120px;

}

.whole img{
  width: 250px; 
  heigth: 250px;
}

.whole h2{
  font-size:30px;
  font-family:Poppins;
  margin-top:-40px;
  border-bottom: 3px solid skyblue;
  
}

.logbtn{
  text-align:right;
}



</style>
</head>

<body>



<div class="logbtn">
 
        <a href="index.html" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-log-out"></span> Log out
        </a>
  </div>
<div class="whole">

<img src="image/logo 1.png">
 <h2>CARS FOR THE MEMBERS</h2>

</div>






 

<div class="categories">
  
     <div class="features">
         
     </div>
      
      
      <div class="row" style="width:100%; margin-left:100px;">
        <div class="column">
          <div class="card">
             <img src="carimage/Toyota.jpg" alt="car_image">
            <h3>Toyota</h3>
            <p>
              <h4>PRICE:40,00000tk</h4>
              <h4>RATING:4 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=40,00000tk&name=Toyota">BUY</a></button>
          </div>
        </div>
      
        <div class="column">
          <div class="card">
             <img src="carimage/ford.jpg" alt="car_image">
            <h3>Ford</h3>
            <p>
              <h4>PRICE:70,00000tk</h4>
              <h4>RATING:4.1 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=70,00000tk&name=Ford">BUY</a></button>
          </div>
        </div>
        
        <div class="column">
          <div class="card">
           <img src="carimage/honda.jpg" alt="car_image">
           <h3>Honda</h3>
            <p>
              <h4>PRICE:90,00000tk</h4>
              <h4>RATING:4.2 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=90,00000tk&name=Honda">BUY</a></button>
          </div>
        </div>
     </div>

    <div class="row" style="width:100%; margin-left:100px;">


     <div class="column">
          <div class="card">
           <img src="carimage/nissan.jpg" alt="car_image">
           <h3>Nissan</h3>
            <p>
              <h4>PRICE:110,00000tk</h4>
              <h4>RATING:4.3 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=110,00000tk&name=Nissan">BUY</a></button>
          </div>
        </div>

      

       <div class="column">
          <div class="card">
           <img src="carimage/bmw.jpg" alt="car_image">
           <h3>Bmw</h3>
            <p>
              <h4>PRICE:130,00000tk</h4>
              <h4>RATING:4.3 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%";><a href="http://localhost/CarShop/payment.php?price=130,00000tk&name=Bmw">BUY</a></button>
          </div>
        </div>

      
       

        <div class="column">
          <div class="card">
           <img src="carimage/audi.jpg" alt="car_image">
           <h3>Audi</h3>
            <p>
              <h4>PRICE:150,00000tk</h4>
              <h4>RATING:4.4 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=150,00000tk&name=Audi">BUY</a></button>
           </div>
        </div>

    </div>

      <div class="row" style="width:100%; margin-left:100px;">


       <div class="column">
          <div class="card">
           <img src="carimage/mercedes.jpg" alt="car_image">
           <h3>Mercedes Benz</h3>
            <p>
              <h4>PRICE:200,00000tk</h4>
              <h4>RATING:4.5 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=200,00000tk&name=Mercedes+Benz">BUY</a></button>
          </div>
        </div>

      

       <div class="column">
          <div class="card">
           <img src="carimage/porsche.jpg" alt="car_image">
           <h3>Porsche</h3>
            <p>
              <h4>PRICE:220,00000tk</h4>
              <h4>RATING:4.6 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=220,00000tk&name=Porsche">BUY</a></button>
          </div>
        </div>

      
       

       <div class="column">
          <div class="card">
           <img src="carimage/rolls_royce.jpg" alt="car_image">
           <h3>Rolls-Royce</h3>
            <p>
              <h4>PRICE:300,00000tk</h4>
              <h4>RATING:4.7 out of 5</h4>
              <h4>Available in stock:YES</h4>
            </p>
            <button id="paybutton" style="width:75%;"><a href="http://localhost/CarShop/payment.php?price=300,00000tk&name=Rolls-Royce">BUY</a></button>
          </div>
        </div>

      </div>

     <footer>

    <div class="row" style="width:100%; margin-left:350px;">

      <div class="col-lg-6">
          <p>No refund after payment</p>
          <p>Thank for you co-operation</p>
          <p>&copy;All rights reserved by Luxury Car Shop</p>

      </div>

      

    </div>
     

  </footer>
      
    
      
    </div>
      
  
    

</div>

</body>
</html>