<?php 
if(session_status()>=0){
    if(isset($_SESSION["uname"])){
        header ("refresh: 0.5; url=private.php");
    }
}

    if(isset($_POST["Login"])){
        $uname=$_POST["uname"];
        $pass=$_POST["upass"];

        $conn=mysqli_connect('localhost','root','','carshopdb');
        $sql="SELECT * From customer Where Username ='$uname' and Password='$pass'"; 

        $result=mysqli_query($conn,$sql);
        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
        $count=mysqli_num_rows($result);

        if($count==1){
            session_start();
            echo "REDIRECTING";
            header("refresh: 2; url=private.php");
            exit();
        }
        else{
            echo"User not found";
            header("refresh: 2; url=login.php");
            exit();
        }
    }

        if(!isset($_POST["Login
        "])){
            echo"Fill the username and password."."<br>";
            header("refresh: 2; url=login.php");
        }
    

        ?>


    
