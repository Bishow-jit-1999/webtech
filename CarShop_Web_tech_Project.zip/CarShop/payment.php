<?php
if(isset($_GET['price'])){
    $price = $_GET['price'];
    $name = $_GET['name'];
}


if(isset($_POST['Confirm'])){
    
    $holdername=$_POST['card_holder'];
    $carnum=$_POST['card_number'];
    $cartype=$_POST['cardtype'];


    $conn=mysqli_connect('localhost','root','','carshopdb');
    $query="INSERT Into carorder(CarName,CarPrice,Cardholder,CardNumber,CardType) VALUES('$name','$price','$holdername','$carnum','$cartype')";
    if(mysqli_query($conn,$query)){
    ?>
 <script>
     alert("Payment successfull !! Your order has been placed !! Thank you")

 </script>

      <?php
        header("refresh:0.5; url=private.php");
    }
  

 else{
     ?>
      <script>
     alert("Payment Failed")
 </script>
 <?php
    header("refresh: 2; url=payment.php");
 }



}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAYMENT</title>
    <link rel="stylesheet" href="paymentstyle.css">
</head>
<body>

   <form action="" method="Post">

      <div class="container">
         <h1>LUXURY CARS BD</h1>
        <h2>Pay <?=$price?> for <?=$name?></h2>

        
        <div class="first-row">
            <div class="owner">
                <h3>Card Holder Name</h3>
                <div class="input-field">
                    <input type="text" id="card_holder" name="card_holder" required>
                </div>
            </div>

            <div class="cvv">
                <h3>CVV</h3>
                <div class="input-field" >
                    <input type="password" id="cvv" required>
                </div>
            </div>
        </div>

        <div class="second-row">
            <div class="card-number">
                <h3>Card Number</h3>
                <div class="input-field">
                    <input type="text" id="card_number" name="card_number" required>
                </div>
            </div>

        </div>

        <div class="third-row">

            <h3>Card Type</h3>
            <select name="cardtype" id="cardtype" name="cardtype" required>>
                <option value=""></option>
                <option value="MASTER_CARD">MASTER CARD</option>
                <option value="VISA_CARD">VISA CARD</option>
                <OPtion value="AMERICAN_EXPRESS_CARD">AMERICAN EXPRESS</OPtion>
            </select>
        </div>
        
        <div class="fourth-row">
            
                <h3>Card valid till</h3>
                <div class="selection">
                    <div class="date">
                        <select name="Month" id="months" required>>
                            <option value=""></option>
                            <option value="JAN">JAN</option>
                            <option value="FEB">FEB</option>
                            <option value="MAR">MAR</option>
                            <option value="APR">APR</option>
                            <option value="MAY">MAY</option>
                            <option value="JUN">JUN</option>
                            <option value="JUL">JUL</option>
                            <option value="AUG">AUG</option>
                            <option value="SEP">SEP</option>
                            <option value="OCT">OCT</option>
                            <option value="NOV">NOV</option>
                            <option value="DEC">DEC</option>
                        </select>

                        <select name="Year" id="years" required>>
                            <option value=""></option>
                            <option value="2021">2021</option>
                            <option value="2022">2022</option>
                            <option value="2023">2023</option>
                            <option value="2024">2024</option>
                            <option value="2025">2025</option>
                            <option value="2026">2026</option>
                            <option value="2027">2027</option>
                            <option value="2028">2028</option>
                            <option value="2029">2029</option>
                            <option value="2030">2030</option>
                            <option value="2031">2031</option>
                        </select>

                    </div>
                    <div class="cards">
                        <img src="mastercard.png" alt="master card" width="80px" height="80px">
                        <img src="visa.png" alt="visa card" width="80px" height="80px">
                        <img src="american_express.jpg" alt="american express" width="80px" height="80px">
                    </div>

                </div>
            

        </div>
        <div class="button">
            
            <input type="submit"  name="Confirm" value="Confirm" class=btn >

        </div>
        
        </div>

    </form>
    
    
    
</body>
</html>