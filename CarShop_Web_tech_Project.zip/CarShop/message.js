const holdername=document.querySelector("#card_holder");
const cvv=document.querySelector("#cvv");
const cardNumber=document.querySelector("#card_number");
const cardtype=document.querySelector("#cardtype");
const month=document.querySelector("#months");
const year=document.querySelector("#years");
const btn=document.querySelector(".btn");

btn.addEventListener('click',function(a){
a.preventDefault();
if(holdername.value!='' && cvv.value!='' && cardNumber.value!='' && cardtype.value!='' && month.value!='' && year.value!='' ){
  
  
   
}
else{
  
   alert('Please fill up the input fields properly!');
}
});