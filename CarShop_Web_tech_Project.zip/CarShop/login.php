<?php 
if(session_status()>=0){
    session_start();
    if(isset($_SESSION["uname"])){
        header("refresh: 1; url=private.php");
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>luxury Car Shop Bd</title>
    <link rel="stylesheet" href="loginstyle.css">
   
</head>
    


<body>

 <form action="loginprocess.php" method="post">

    <div class="login-box">

    <h1>Luxury Cars BD</h1>

    <div class="textbox">
    <i class="fa fa-user" aria-hidden="true"></i>
    <input type="text" name="uname" required placeholder="Username" >
    </div>
   
    <div class="textbox">
    <i class="fa fa-lock" aria-hidden="true"></i>
    <input type="password" name="upass" required placeholder="Password">
    </div>


  <input class="btn" type="submit" value="Login" name="Login">
<div class="sign_up">

<a href="signup.php">Sign Up</a>
</div>
  

</div>
 </form>
    
</body>
</html>