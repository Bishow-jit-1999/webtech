<?php 
if (session_status()>=0){
    session_start();
    if(isset($_SESSION["uname"])){
        header("refresh: 0.5; url=private.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>luxury Car Shop Bd</title>
     <link rel="stylesheet" href="signupstyle.css">
</head>

 
<body>

 <form action="process.php" method="post">
     <div class="reg-box">
    <h1>Registration</h1>

    <div class="textbox">
    <i class="fa fa-users" aria-hidden="true"></i>
    <input type="text" name="name" required placeholder="Name" >
    </div>

    <div class="textbox">
    <i class="fa fa-phone" aria-hidden="true"></i>
    <input type="text" name="uphone" required placeholder="Phone" >
    </div>
     
    <div class="textbox">
    <i class="fa fa-envelope" aria-hidden="true"></i>
    <input type="text" name="uemail" required placeholder="Email" >
    </div>

    <div class="textbox">
    <i class="fa fa-briefcase" aria-hidden="true"></i>
    <input type="text" name="uoccupation" required placeholder="Occupation" >
    </div>

    <div class="textbox">
    <i class="fa fa-map-marker" aria-hidden="true"></i>
    <input type="text" name="uaddress" required placeholder="Address" >
    </div>

    <div class="textbox">
    <i class="fa fa-user" aria-hidden="true"></i>
    <input type="text" name="uname" required placeholder="Username" >
    </div>

    <div class="textbox">
    <i class="fa fa-lock" aria-hidden="true"></i>
    <input type="password" name="upass" required placeholder="Password" >
    </div>

    <div class="textbox">
    <i class="fa fa-lock" aria-hidden="true"></i>
    <input type="password" name="conpass" required placeholder="Re-type Password" >
    </div>
    
 <!--<label for="name">Name:</label> 
 <input type="text" name="name" required placeholder="Name"><br><br>
 <label for="uphone">Phone:</label>
 <input type="text" name="uphone"  required placeholder="Phone"><br><br>
 <label for="uemail">Email:</label>
 <input type="text" name="uemail"  required placeholder="Email"><br><br>
 <label for="uoccupation">Occupation:</label>
 <input type="text" name="uoccupation"  required placeholder="Occupation"><br><br>
 <label for="uaddress">Address:</label>
 <input type="text" name="uaddress"  required placeholder="Address"><br><br>
 <label for="uname">Username:</label>
 <input type="text" name="uname"  required placeholder="Username"><br><br>
 <label for="upass">Password:</label> 
 <input type="password" name="upass" required placeholder="Password"><br><br>
 <label for="conpass">Confirm Password:</label>
 <input type="password" name="conpass" required placeholder="Re-type Password"><br><br>-->
 
 <input class="btn" type="submit" name="REGISTER" value="REGISTER" >
 </div>
 
 


 
 </form>
    
</body>


</html>